$(document).ready(function(){
  $('.menu-tab').click(function(){
    $('.menu-hide').toggleClass('show');
    $('.menu-tab').toggleClass('active');
  });

 /* $('a').click(function(){
    $('.menu-hide').removeClass('show');
    $('.menu-tab').removeClass('active');
  });*/
$('.show-more').click(function(){
	$('.users-options').toggleClass('show');
});

//handle select all checkbox

$("#all").change(function(){  //"select all" change 
	$(".choice input").prop('checked', $(this).prop("checked")); //change all ".choice input" checked status
    $(".choice input").parents('tr').addClass('actif');
  
  //if parent all is unchecked 
    if(false==$("#all").prop('checked')){
    	$(".choice input").parents('tr').removeClass('actif');
    }

});

//".choice input" change 
$('.choice input').change(function(){ 
    //uncheck "select all", if one of the listed checkbox item is unchecked
    if(false == $(this).prop("checked")){ //if this item is unchecked
        $("#all").prop('checked', false); //change "select all" checked status to false
         $(this).parents('tr').removeClass('actif');
    }
    //check "select all" if all checkbox items are checked
    if ($('.choice input:checked').length == $('.choice input').length ){
        $("#all").prop('checked', true);
    }

    if(true == $(this).prop("checked")){ //if this item is checked
       $(this).parents('tr').addClass('actif');
    }
});




//** handle accordeon **//

$('.card a' ).click(function() {
    $child1 = $(this).parents('.card-header').siblings('.collapse');
    /*console.log($child1);*/

    if($child1.hasClass('show')){
        $(this).parents('.card-header').addClass('in');
    }
    else{
     $(this).parents('.card-header').removeClass('in');
       
    }
    
    
});




}); //document ready